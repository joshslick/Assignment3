import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.css";

const Shop = () => {
    const [catalog, setCatalog] = useState([]);
    const [cart, setCart] = useState([]);
    const [cartTotal, setCartTotal] = useState(0);
    const [view, setView] = useState("shop"); // "shop" or "checkout" view
    const [searchTerm, setSearchTerm] = useState(""); // Search term state

    const addToCart = (el) => {
        setCart([...cart, el]);
    };

    const removeFromCart = (el) => {
        let itemFound = false;
        const updatedCart = cart.filter((cartItem) => {
            if (cartItem.id === el.id && !itemFound) {
                itemFound = true;
                return false;
            }
            return true;
        });
        if (itemFound) {
            setCart(updatedCart);
        }
    };

    const handleCheckout = () => {
        setView("checkout"); // Switch to the checkout view
    };

    const howManyofThis = (id) => {
        return cart.filter(cartItem => cartItem.id === id).length;
    };

    useEffect(() => {
        const total = () => {
            let totalAmount = 0;
            for (let i = 0; i < cart.length; i++) {
                totalAmount += cart[i].price;
            }
            setCartTotal(totalAmount);
        };
        total();
    }, [cart]);

    useEffect(() => {
        const fetchData = async () => {
            const someResponse = await fetch("./products.json");
            const data = await someResponse.json();
            setCatalog(data);
        };
        fetchData();
    }, []);

    // Filter catalog based on search term
    const filteredCatalog = catalog.filter(el =>
        el.title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const listItems = filteredCatalog.map((el) => (
        <div className="row border-top border-bottom" key={el.id}>
            <div className="row main align-items-center">
                <div className="col-2">
                    <img className="img-fluid" src={el.image} alt={el.title} />
                </div>
                <div className="col">
                    <div className="row text-muted">{el.title}</div>
                    <div className="row">{el.category}</div>
                </div>
                <div className="col">
                    <button type="button" className="btn btn-light" onClick={() => removeFromCart(el)}> - </button>{" "}
                    <button type="button" className="btn btn-light" onClick={() => addToCart(el)}> + </button>
                </div>
                <div className="col">
                    ${el.price} <span className="close">&#10005;</span>{howManyofThis(el.id)}
                </div>
            </div>
        </div>
    ));

    // Cart summary for checkout view
    const cartSummary = (
        <div>
            <h3>Cart Summary</h3>
            {cart.length === 0 ? (
                <p>Your cart is empty.</p>
            ) : (
                <div>
                    {cart.map((el, index) => (
                        <div key={index} className="d-flex justify-content-between">
                            <span>{el.title} x {howManyofThis(el.id)}</span>
                            <span>${el.price}</span>
                        </div>
                    ))}
                    <hr />
                    <div className="d-flex justify-content-between">
                        <strong>Total:</strong>
                        <strong>${cartTotal.toFixed(2)}</strong>
                    </div>
                </div>
            )}
        </div>
    );

    // Checkout view content
    const checkoutView = (
        <div>
            {cartSummary}
            <h2>Checkout</h2>
            <p>Your total is: ${cartTotal}</p>
            <form>
                <div className="form-group">
                    <label htmlFor="name">Name</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="name">Email</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="cardNumber">Credit Card Number</label>
                    <input type="text" className="form-control" id="cardNumber" required />
                </div>
                <div className="form-group">
                    <label htmlFor="shippingAddress">Shipping Address</label>
                    <input type="text" className="form-control" id="shippingAddress" required />
                </div>
                <div className="form-group">
                    <label htmlFor="name">address</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="name">city</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="name">state</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <div className="form-group">
                    <label htmlFor="name">zip code</label>
                    <input type="text" className="form-control" id="name" required />
                </div>
                <button type="submit" className="btn btn-primary mt-3">Place Order</button>
            </form>
            <button className="btn btn-secondary mt-3" onClick={() => setView("shop")}>Back to Shop</button>
        </div>
    );

    const shopView = (
        <div>
            <h3>Catalog</h3>
            <div className="form-group">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Search for products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div>{listItems}</div>
            {/* Checkout Button */}
            <div className="text-right mt-3">
                <button className="btn btn-success" onClick={handleCheckout}>Checkout</button>
            </div>
        </div>
    );

    return (
        <div>
            <h2>STORE SE/ComS3190</h2>
            {view === "shop" && shopView}
            {view === "checkout" && checkoutView}
        </div>
    );
};

export default Shop;
