import React, { useState } from "react";
const Cart = ({ cart, cartTotal }) => {
    const [formData, setFormData] = useState({
        name: "",
        address: "",
        city: "",
        state: "",
        zip: "",
        cardNumber: "",
        expirationDate: "",
        cvv: ""
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const calculateTotalWithTax = (total) => {
        const taxRate = 0.07; // 7% tax rate
        return total + total * taxRate;
    };

    const handleCheckout = (e) => {
        e.preventDefault();
        // Here, you can add logic to handle the checkout process
        console.log("Checkout data:", formData);
        // Reset the cart and form data if necessary
    };

    const howManyofThis = (id) => {
        return cart.filter(cartItem => cartItem.id === id).length;
    };

    return (
        <div className="container">
            <h2>Your Shopping Cart</h2>
            <div className="card">
                <div className="card-body">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cart.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.title}</td>
                                    <td>{howManyofThis(item.id)} </td>
                                    <td>${item.price.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <h4>Total: ${cartTotal.toFixed(2)}</h4>
                    <h4>Total with Tax: ${calculateTotalWithTax(cartTotal).toFixed(2)}</h4>
                </div>
            </div>

            <h3>Checkout</h3>
            <form onSubmit={handleCheckout}>
                <div className="form-group">
                    <label>Name</label>
                    <input type="text" className="form-control" name="name" value={formData.name} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <input type="text" className="form-control" name="address" value={formData.address} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>City</label>
                    <input type="text" className="form-control" name="city" value={formData.city} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>State</label>
                    <input type="text" className="form-control" name="state" value={formData.state} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>ZIP Code</label>
                    <input type="text" className="form-control" name="zip" value={formData.zip} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Card Number</label>
                    <input type="text" className="form-control" name="cardNumber" value={formData.cardNumber} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Expiration Date</label>
                    <input type="text" className="form-control" name="expirationDate" value={formData.expirationDate} onChange={handleChange} required placeholder="MM/YY" />
                </div>
                <div className="form-group">
                    <label>CVV</label>
                    <input type="text" className="form-control" name="cvv" value={formData.cvv} onChange={handleChange} required />
                </div>
                <button type="submit" className="btn btn-primary">Checkout</button>
            </form>
        </div>
    );
};

export default Cart;